# SHAC Studio — Hearth Family v2.0

Market direction: Residential.

Visual character: warm domestic.

This is a public generic template family. It contains no client-specific room names, addresses, group addresses, or commissioned project labels.
