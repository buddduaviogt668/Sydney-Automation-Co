# SHAC_Commercial_Venue_Add-on_v2.0

A public generic SHAC Studio package. All sample labels are placeholders for the purchaser to replace. Includes complete sample project screens, widgets, icons, device variants, manuals and licences.
