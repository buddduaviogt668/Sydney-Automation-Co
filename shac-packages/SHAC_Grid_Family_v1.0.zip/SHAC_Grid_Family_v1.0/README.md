# SHAC Studio — Grid Family System v1.0

**Market:** Office / Commercial

Clear floor plans, occupancy, HVAC and energy status for working buildings.

This is an original SHAC Studio visual family for integrators building interfaces across C-Bus, KNX, Savant, Control4 and Crestron projects.

## Included

The package contains editable SVG floor-plan, room-page, widget-dashboard and scene-control templates; device variants for tablet, iPad, phone and Full HD composition; and an eight-domain icon sheet.

Use these assets as a starting system. Adapt labels, states, colours and controls to the commissioned project and test the finished UI on the target hardware.
