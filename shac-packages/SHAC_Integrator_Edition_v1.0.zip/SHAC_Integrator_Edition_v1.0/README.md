# SHAC_Integrator_Edition_v1.0

Generic, original SHAC Studio assets with neutral placeholders only. Replace Zone 01, Device Name, Scene Status and other sample labels with the integrator project vocabulary.
