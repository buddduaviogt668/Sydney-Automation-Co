# SHAC Studio — Social Public Family v1.0

Market: Pub / Bar.

This package contains original generic assets only. Labels such as Zone 01, Device Name, Scene Status and Room A are placeholders for the purchaser to replace. No client addresses, group addresses, or commissioned project names are included.
