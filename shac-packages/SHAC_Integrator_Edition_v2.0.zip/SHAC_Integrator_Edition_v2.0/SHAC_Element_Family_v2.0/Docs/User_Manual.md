# Element Family v2.0

This family is for **Pool / Spa / Garden**. It includes a floor plan, room detail page, scene control page, status dashboard, widget library, icon library, and four device variants. All labels are neutral sample content and are intended to be replaced.
