# SHAC Studio — Social Family v2.0

Market direction: Pub / Bar.

Visual character: social entertainment.

This is a public generic template family. It contains no client-specific room names, addresses, group addresses, or commissioned project labels.
